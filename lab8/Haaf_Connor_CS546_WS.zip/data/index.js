const tvData = require('./tvApi');

module.exports = {
  tv: tvData,
};